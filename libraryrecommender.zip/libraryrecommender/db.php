<?php
	$conn = mysqli_connect("localhost","root","","recommendation_system");
?>