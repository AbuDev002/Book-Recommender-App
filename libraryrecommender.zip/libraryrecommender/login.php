<?php
session_start();
ob_start();
 include_once("db.php");
 ?>
<!DOCTYPE html>
<html>
<head>
<title>Intelligent Library Readers Book Recommender System</title>
 <!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/jquery-ui.css" rel="stylesheet" type="text/css" media="screen">
<!-- <link rel="shortcut icon" href="images/fav.jpg" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen"> -->
<style>
	.error{
		color:red;
	}
	#login_form #loading_spinner
	{
	 display:none;
	}
</style>
</head>
<body>

<!-- navigation -->
<nav class="navbar navbar-light bg-light">
  <div class="container-fluid">
    <!-- <a class="navbar-brand" href="#">
      INTELLIGENT LIBRARY READERS BOOK RECOMMENDER SYSEM
    </a> -->
  </div>
</nav>
<!-- end of navigation -->
<br>
<br>
<div class="container">	
	<div class="row">
		<div class="col-md-8" style="background:url('images/front_image.jpg') no-repeat;background-size:contain;height:400px;border-radius:5px;">
			
			
		</div>
		<div class="col-md-4">
			<div class="panel panel-default">
				<div class="panel-heading">Login Area</div>
				<div class="panel-body">
					<form  id="login_form" method="post" action="do_login.php" onsubmit="return do_login();">
					<div id="error"></div>
					
					<div class="mb-3">
					  <label for="username" class="form-label">Username</label>
					  <input type="text" class="form-control" name="username" id="username" placeholder="Username..." autocomplete="off">
					 <!--  <span id="check-e"></span> -->
					</div>

					<div class="mb-3">
						<label for="password" class="form-label">Password</label>
						<input type="password" name="password" id="password" class="form-control" placeholder="Password..."/>
					</div>
					<hr />
					<div class="mb-3">
						<button type="submit" class="btn btn-light">
						<span class="glyphicon glyphicon-log-in"></span> &nbsp; Sign In
						</button> 
					</div>
					<center><p id="loading_spinner"><img src="ajax-loader.gif"></p></center>
					
				</form>
				</div>
			</div>
		</div>
	</div>
	 <br>	
	<small><p class="text-center lh-lg">&copy <?php echo date('Y'); ?> All rights reserved. Muhammadu Wabi Library Fed. Poly Bauchi</p>	</small>
</div>
<script async src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- <script async  src="js/validation.min.js"></script> -->
<!-- <script async src="js/login.js"></script> -->
<script type="text/javascript">
function do_login()
{
 var username=$("#username").val();
 var password=$("#password").val();
 if(username!="" && password!="")
 {
  $("#loading_spinner").css({"display":"block"});
  $.ajax({
  type:'post',
  url:'do_login.php',
  data:{
   do_login:"do_login",
   username:username,
   password:password
  },
  success:function(response) {
  if(response=="success")
  {
   // window.location.href="index.php";
    //window.location.href="dashboard.php";
	$("#error").css({"display":"none"});
	setTimeout('window.location.href ="index.php"; ',3000);
  }
  else
  {
    $(".loading_spinner").css({"display":"none"});
	//alert("Wrong Details");
	$("#error").html('<div class="alert alert-danger">Invalid Username or Password</div>');
  }
  }
  });
 }
 else
 {
  //alert("Please Fill All The Details");
  $("#error").html('<div class="alert alert-danger">Please Fill All The Details</div>');
 }
 return false;
}
</script>
</body>
</html>