<?php
  include('header.php');
  include("db.php");
?>
      <div class="panel panel-default">
       <?php include_once('nav.php');?>
        <div class="panel-body">
           <div class="row">
             <div class="col-md-6">
               <table class="table table-stripped" id="custom_table">
                  <thead>
                  <tr>
                    <th>S/N</th>
                    <th>Book</th>
                    <th></th>
                  </tr> 
                  </thead>
                  <tbody>
                    <?php
                       $sn = 0;
                       $books = mysqli_query($conn,"select distinct book_name from user_books order by id desc");
                        while($row = mysqli_fetch_array($books)){
                          $sn++;
                    ?> 
                    <tr>
                      <td><?php echo $sn;?></td>
                      <td><?php echo $row['book_name'];?></td>
                      <td><a href="read_rate_books.php?bn=<?php echo $row['book_name'];?>">Read/Rate Books</a></td>
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
             </div>
             <div class="col-md-6">
               <center><h4>RECOMMENDED BOOKS FOR YOU</h4></center>
               <?php
                  include('db.php');
                  include('recommend.php');

                  $books = mysqli_query($conn,"select * from user_books");
                  while($book = mysqli_fetch_array($books)){
                    $users = mysqli_query($conn,"select username from users where id='".$book['user_id']."'");
                    $username = mysqli_fetch_array($users);
                    $matrix[$username['username']][$book['book_name']] = $book['book_rating'];
                  }

                  $users = mysqli_query($conn,"select username from users where id='".$userid."'");
                  $username = mysqli_fetch_array($users);
                  
                ?>

                 <table class="table table-stripped">
                    <tr>
                      <th>Book Name</th>
                      <th>Book Rating</th>
                      <th></th>
                    </tr>
                    <?php
                      $recommendation = array();
                      $recommendation = getRecommendation($matrix,$username['username']);
                      foreach ($recommendation as $book => $rating) {
                        
                     ?>
                        <tr>
                          <td><?php echo $book;?></td>
                          <td><?php echo $rating;?></td>
                          <td><a href="#" data-bs-toggle="modal" data-toggle="modal" data-target="#myModal">Read Book</a></td>
                       
                         </tr>
                      <?php } ?>
                  </table>
             </div>
           </div>
        </div>
      </div>
    </div>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Book Details</h4>
      </div>
      <div class="modal-body">
        <iframe src="java_tutorial.pdf" width="100%" height="500px"></iframe>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
      </div>
    </div>
  </div>
</div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/datatable.js" ></script>
    <script type="text/javascript">
      $('#custom_table').dataTable();
    </script>
  </body>
</html>