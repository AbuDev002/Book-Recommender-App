<?php
session_start();
ob_start();
if(!isset($_SESSION['userid'])){
	header("Location: login.php");
}
$userid = $_SESSION['userid'];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Inelligent Library Recommender System</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/jquery-ui.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
     <link rel="stylesheet" type="text/css" href="css/datatable.min.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     <style type="text/css">
       .checked {
          color: orange;
        }
     </style>
  </head>
  <body>
    <div class="container">
      <h2><div class="well text-cener">INTELLIGENT LIBRARY READER'S BOOK RECOMMENDER SYSTEM</div></h2>