<?php
include("header.php");
include("db.php");
$flag =0;
if(isset($_POST['submit']))
{
	$username = $_POST['username'];
	$result = mysqli_query($conn,"insert into users (username) value('$username')");
	if($result){
		$flag =1;
	}
}
?>

<div class="panel panel-default">
	<?php include_once('nav.php');?>
	<?php if($flag){?>
		<div class="alert alert-sucess">
			User successfully inserted into database
		</div>
	<?php } ?>
	<div class="panel-body">
		<form action="add_user.php" method="post">
			<div class="form-group">
				<label for="username">User Name</label>
			<input type="text" name="username" id="username" class="form-control" required>
			</div>
			<div class="form-group">
				<input type="submit" name="submit" value="Submit" class="btn btn-primary">
			</div>
		</form>
	</div>

</div>