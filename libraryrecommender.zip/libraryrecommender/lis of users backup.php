<table class="table table-stripped">
            <tr>
              <th>Username</th>
              <th>Add Books</th>
              <th>Show Books</th>
              <th>Show Recommendation</th>
            </tr>
            <?php
              $result = mysqli_query($conn,"select * from users");
              while($row = mysqli_fetch_array($result)){?>
                <tr>
                  <td><?php echo $row['username'];?></td>
                <!-- </tr> -->
               <!--  <tr> -->
                  <td>
                    <form action="add_books.php">
                      <input type="submit" name="add_books" class="btn btn-primary" value="Add Books">
                      <input type="hidden" name="id" value="<?php echo $row['id'];?>">
                    </form>
                  </td>

                  <td>
                    <form action="show_books.php">
                      <input type="submit" name="show_books" class="btn btn-primary" value="Show Books">
                      <input type="hidden" name="id" value="<?php echo $row['id'];?>">
                    </form>
                  </td>

                  <td>
                    <form action="user_recommendation.php">
                      <input type="submit" name="show_books" class="btn btn-primary" value="Show Recommendation">
                      <input type="hidden" name="id" value="<?php echo $row['id'];?>">
                    </form>
                  </td>
                </tr>
              <?php } ?>
            
            
          </table>