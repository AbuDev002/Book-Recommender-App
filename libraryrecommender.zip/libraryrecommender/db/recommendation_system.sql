-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2021 at 02:52 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `recommendation_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'abbkar', 'password'),
(2, 'John', 'password'),
(3, 'Wilson', 'password'),
(4, 'Musa', 'password'),
(5, 'Halima', 'password');

-- --------------------------------------------------------

--
-- Table structure for table `user_books`
--

CREATE TABLE `user_books` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_name` varchar(100) NOT NULL,
  `book_rating` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_books`
--

INSERT INTO `user_books` (`id`, `user_id`, `book_name`, `book_rating`) VALUES
(1, 1, 'Rambo', '5.0'),
(2, 1, 'Rockey', '3.0'),
(3, 1, 'Garden State', '2.0'),
(4, 2, 'Rambo', '2.0'),
(5, 2, 'Rockey', '2.0'),
(6, 2, 'Garden State', '5.0'),
(7, 3, 'Rambo', '2.0'),
(8, 3, 'Before sunset', '4.0'),
(9, 3, 'Thor', '5.0'),
(10, 2, 'Before sunset', '2.0'),
(11, 4, 'Rambo', '5.0'),
(12, 4, 'Garden State', '3.0'),
(13, 4, 'Before sunset', '4.0'),
(14, 5, 'Rambo', '4.0'),
(15, 5, 'Rockey', '3.0'),
(16, 5, 'Garden State', '2.0'),
(17, 5, 'Before sunset', '4.0'),
(18, 5, 'Training Day', '3.0'),
(19, 1, 'Prison Break', '5'),
(20, 4, 'Beginner PHP programming', '3.0'),
(21, 4, 'Web design using HTML', '4.0'),
(22, 5, 'Prison Break', '4.0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_books`
--
ALTER TABLE `user_books`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_books`
--
ALTER TABLE `user_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
