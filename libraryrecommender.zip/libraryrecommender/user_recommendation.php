<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Library Recommender System</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
    <div class="container">
      <h2><div class="well text-cener">RECOMMENDATION FOR YOU:</div></h2>
<?php
	include('db.php');
	include('recommend.php');

	$books = mysqli_query($conn,"select * from user_books");
	while($book = mysqli_fetch_array($books)){
		$users = mysqli_query($conn,"select username from users where id='".$book['user_id']."'");
		$username = mysqli_fetch_array($users);
		$matrix[$username['username']][$book['book_name']] = $book['book_rating'];
	}

	$users = mysqli_query($conn,"select username from users where id='".$_GET['id']."'");
	$username = mysqli_fetch_array($users);
	
?>

 <div class="panel panel-default">
        <?php include_once('nav.php');?>
        <div class="panel-body">
          <table class="table table-stripped">
            <tr>
              <th>Book Name</th>
              <th>Book Rating</th>
            </tr>
            <?php
            	$recommendation = array();
            	$recommendation = getRecommendation($matrix,$username['username']);
            	foreach ($recommendation as $book => $rating) {
            		
             ?>
                <tr>
                  <td><?php echo $book;?></td>
                  <td><?php echo $rating;?></td>
               
                 </tr>
              <?php } ?>
            
            
          </table>
        </div>
      </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>