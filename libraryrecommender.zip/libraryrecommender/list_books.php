<?php
include('header.php');
include("db.php");
?>
<div class="panel panel-default">
 <?php include_once('nav.php');?>
 <div class="panel-body">
   <div class="row">
     <div class="col-md-6">
       <center><h4>LIST OF BOOKS IN THE LIBRARY</h4></center>
       <table class="table table-stripped">
        <tr>
          <th>Book Name</th>
          <th>Book Author</th>
          <th></th>
        </tr>
        <?php
        include('db.php');
        $books = mysqli_query($conn,"select * from book_list");
        while($book = mysqli_fetch_array($books)){
         ?>
         <tr>
          <td><?php echo $book['book_name'];?></td>
          <td><?php echo $book['book_author'];?></td>
          <td><a href="#" id="booking_form">Read Book</a></td>

        </tr>
      <?php } ?>
    </table>
  </div>
   <div class="col-md-6">
  <?php if($_SESSION['account_type'] =="admin"){?>
 
 <?php
          if($_SERVER['REQUEST_METHOD'] =='POST'){
            $book_name = $_POST['book_name'];
            $book_author = $_POST['book_author'];
            
            $permited  = array('jpg', 'jpeg', 'png', 'gif', 'pdf');
            $file_name = $_FILES['book_file']['name'];
            $file_size = $_FILES['book_file']['size'];
            $file_temp = $_FILES['book_file']['tmp_name'];

            $div = explode('.', $file_name);
            $file_ext = strtolower(end($div));
            $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
            $uploaded_image = "books_upload/".$unique_image;
            
            if($book_name ==""){
              $msg = "<p class='alert alert-danger'>Please enter book name and author</p>";
            }elseif ($file_size >1048567) {
             $msg ="<p class='alert alert-danger'>Image Size should be less then 1MB!
             </p>";
            } elseif (in_array($file_ext, $permited) === false) {
              $msg ="<p class='alert alert-danger'>You can upload only:-".implode(', ', $permited)."</p>";
            } else{
              move_uploaded_file($file_temp, $uploaded_image);
               $newbook = mysqli_query($conn, "INSERT INTO book_list (book_name, book_author,book_file) VALUES ('$book_name', '$book_author','$uploaded_image')");
            if ($newbook) {
              $msg ="<p class='alert alert-success'>Data Inserted Successfully.
             </p>";
            }else {
              $msg ="<p class='alert alert-danger'>Data Not Inserted !</p>";
            }
          }
        }
?>
 <h4>Add New Book</h4>
 <?php if(isset($msg)){ echo $msg;}?>
 <form action="" method="post" enctype="multipart/form-data">
  <div class="form-group">
    <input type="text" name="book_name" class="form-control" placeholder="Book name...">
  </div>
  <div class="form-group">
    <input type="text" name="book_author" class="form-control" placeholder="Book author...">
  </div>
  <div class="form-group">
    <input type="file" name="book_file" />
  </div>
  <div class="form-group">
    <button type="submit" class="btn btn-success" name="btnAddbook">Add Book</button>
  </div>
</form>

<?php } ?>
<div class="row animate__animated animate__zoomIn" id="booking_env" style="display: none;">
  <div class="col-md-12">
    <?php //echo $path.$pdf; ?>
    <!-- <h4>Borrow A Book</h4> -->
    <iframe src="java_tutorial.pdf" width="90%" height="500px">
</iframe>
   
  </div>
</div>
</div>
</div>
</div>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/datatable.js" ></script>
<script type="text/javascript">
  $('#custom_table').dataTable();
</script>
 <script type="text/javascript"> 
      $(document).ready(function()
      {  
         $("#booking_form").click(function() {
         $("#booking_env").show()
         });  
       });      
   </script>
</body>
</html>