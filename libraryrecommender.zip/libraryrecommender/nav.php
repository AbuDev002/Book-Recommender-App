 <div class="panel-heading" style="padding:0px;margin-top:0px;">
    <ul class="nav nav-pills">
	  <li><a href="index.php">Dashboard</a></li>
	  <li><a href="list_books.php">List of Books</a></li>
	  <!-- <li><a href="#">Add Books</a></li> -->
	  <li class="pull-right">
	  	<ul  class="nav nav-pills">
		<li><a href="logout.php">Logout</a></li>
	</ul>
	  </li>
	</ul>

</div>