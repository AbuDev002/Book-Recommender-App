<?php
//session_start();
include("header.php");
// if(isset($_GET['id'])){
// 	$_SESSION['id'] = $_GET['id'];
// }
$userid = $_SESSION['userid'];
include("db.php");
$flag =0;
if(isset($_POST['submit']))
{
	$book_name = $_POST['book_name'];
	$book_rating = $_POST['book_rating'];
	$result = mysqli_query($conn,"insert into user_books (user_id,book_name,book_rating) value('".$userid."','$book_name','$book_rating')");
	if($result){
		$flag =1;
	}
}
?>
<div class="panel panel-default">
	<?php include_once('nav.php');?>
	<?php if($flag){?>
		<div class="alert alert-success">
			Book Rated Successfully.
		</div>
	<?php } ?>
	<div class="panel-body">
		<div class="row">
			<div class="col-md-6">
				<form action="read_rate_books.php" method="post">
			<div class="form-group">
				<h2>Book Recommendation/Rating</h2>
				<span class="fa fa-star checked"></span>
				<span class="fa fa-star checked"></span>
				<span class="fa fa-star checked"></span>
				<span class="fa fa-star checked"></span>
				<span class="fa fa-star checked"></span>
			</div>	
			<div class="form-group">
				<label for="books">Books Name</label>
				<input type="text" name="book_name" id="book_name" value="<?php if(isset($_GET['bn'])){echo $_GET['bn'];}?>" class="form-control" placeholder="Enter book name..." required style="width:300px;">
			
		</div>
		<div class="form-group">
			<label for="rating">Rating</label>
			<!-- <input type="text" name="book_rating" id="book_rating" class="form-control" required> -->
			<select name="book_rating" id="book_rating" class="form-control" style="width:300px;" required>
				<option>--Select Rating--</option>
				<option value="5.0">5.0</option>
				<option value="4.0">4.0</option>
				<option value="3.0">3.0</option>
				<option value="2.0">2.0</option>
				<option value="1.0">1.0</option>
			</select>
		</div>
		<div class="form-group">
			<input type="submit" name="submit" value="Submit" class="btn btn-primary">
		</div>
	</form>
			</div>
			<div class="col-md-6">
				<center><h1><?php if(isset($_GET['bn'])){echo $_GET['bn'];}?></h1></center>
				<iframe src="java_tutorial.pdf" width="100%" height="500px">
				</iframe>
			</div>
		</div>

</div>

</div>


