<?php
session_start();
if(isset($_POST['do_login']))
{
include_once('db.php');
 $username=$_POST['username'];
 $password=$_POST['password'];
 $select_data=mysqli_query($conn,"select * from users where username='".$username."' and password='".$password."'");
 if($row=mysqli_fetch_array($select_data))
 {
  $_SESSION['userid']=$row['id'];
  $_SESSION['account_type']=$row['account_type'];
  echo "success";
 }
 else
 {
  echo "fail";
 }
 exit();
}
?>